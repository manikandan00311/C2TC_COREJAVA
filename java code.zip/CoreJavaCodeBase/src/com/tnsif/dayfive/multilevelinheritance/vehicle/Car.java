package com.tnsif.dayfive.multilevelinheritance.vehicle;

public class Car {
	public Car() {
		System.out.println("Class Car");
	}

	public void vehicleType() {
		System.out.println("Vehicle Type: Car");
	}

}
	